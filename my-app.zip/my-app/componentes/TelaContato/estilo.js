import React from "react";
import { Text, ImageBackground } from "react-native";


export default function TelaContato () {
    return(
        <ImageBackground>
            <Text></Text>
        </ImageBackground>
    )
}