import React from "react";
import { Text, ImageBackground } from "react-native";


export default function TelaCatalogo () {
    return(
        <ImageBackground>
            <Text></Text>
        </ImageBackground>
    )
}